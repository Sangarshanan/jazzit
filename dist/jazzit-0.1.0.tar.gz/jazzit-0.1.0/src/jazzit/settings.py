import os

os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "hide"

current_dir, _ = os.path.split(__file__)
